Response Filter with DynamicFeature
========================
Implements a @MaxAge annotation that binds a response filter via a DynamicFeature.  Models example given in Chapter 12.

Auch hier wieder Übersteuerung für deep reflection notwendig!
--add-opens java.base/java.lang=ALL-UNNAMED