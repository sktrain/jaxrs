WriterInterceptor
========================
This project implements a WriterInterceptor that generates a Content-MD5 header hash of the message body.

Auch hier wieder Übersteuerung für deep reflection notwendig!
--add-opens java.base/java.lang=ALL-UNNAMED