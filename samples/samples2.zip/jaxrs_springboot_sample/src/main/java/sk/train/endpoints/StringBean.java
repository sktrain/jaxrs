package sk.train.endpoints;


import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class StringBean {

    private String s;

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }
}
