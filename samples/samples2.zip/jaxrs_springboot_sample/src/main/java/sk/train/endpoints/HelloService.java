package sk.train.endpoints;


import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.xml.bind.JAXB;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

import java.io.File;
import java.io.StringWriter;

@Path("/hallo")
public class HelloService {

	@GET
	//@Produces("text/plain")
	public String sayHello(){
		return "Hallo";
	}

	@GET
	@Path("/text/{input}")
	@Produces("text/plain")
	public String sayHello(@PathParam("input") String in){
		return "Hallo " + in;
	}

	@GET
	@Path("/htmlhallo")
	@Produces("text/html")
	public String sayHelloHtml(){
		return "<html><title>huhu</title><body>Hallo Du</body></html>";
	}

	@GET
	@Path("/xmlhallo")
	@Produces("application/xml")
	public String sayHelloXML(){
		//XML kann per Hand erzeugt werden, besser wäre aber Mapping, wie im JSON-Sample
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
				"<string>Hallo Du</string>";
	}

	@GET
	@Produces("application/json")
	@Path("/jsonhallo")
	public StringBean sayHelloJson(){
		//simpler String eingepackt in Hilfs-Bean
		StringBean sb = new StringBean();
		sb.setS("Hallo");
		return sb;
	}

}
