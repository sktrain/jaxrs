Link Headers and UriBuilder
===========================
This project is an example of using UriBuilder to enable HATEOAS through Link headers

Auch hier wieder Übersteuerung für deep reflection notwendig!
--add-opens java.base/java.lang=ALL-UNNAMED