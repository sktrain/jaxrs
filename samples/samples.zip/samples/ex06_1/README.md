JAX-RS and JAXB
========================
This project is a simple example showing usage of the built in JAXB provider.

Damit das mit dem vorhandenen Test klappt muss in Java 17 vm-Option gestzt werden:
--add-opens java.base/java.lang=ALL-UNNAMED