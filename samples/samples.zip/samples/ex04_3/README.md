Locators and Subresources
========================
Shows an example of Locators and Subresources.
