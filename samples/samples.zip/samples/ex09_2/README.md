HTTP Content Negotiation
=========================
This project is an example of using HTTP conneg to pick between XML and HTML and plain text using file name suffix
mappings provided by RESTEasy.


Use these links:

http://localhost:8080/ex09_2/services/customers/1
http://localhost:8080/ex09_2/services/customers/1.txt
http://localhost:8080/ex09_2/services/customers/1.html


Funktoniert nicht sauber in der aktuellen Version!!
