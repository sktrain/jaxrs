CacheControl and Other things
===========================
This project is a simple example showing usage CacheControl and Request.evaluatePreconditions().

Auch hier wieder Übersteuerung für deep reflection notwendig!
--add-opens java.base/java.lang=ALL-UNNAMED