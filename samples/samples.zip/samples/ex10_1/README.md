Linking and UriBuilder
===========
This project is an example of using UriBuilder to enable HATEOAS through Atom links

