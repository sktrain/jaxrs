JAXRS auf Basis Jersey mittels Spring Boot (spendiert eigenen Starter für die Einbindung).
JSON kann mit diesen Dependencies produziert werden, XML leider nicht ohne weiteres.