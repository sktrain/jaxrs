Injection Annotations
========================
This project is a simple example showing usage of JAX-RS injection annotations.
