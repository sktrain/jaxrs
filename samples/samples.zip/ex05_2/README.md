Injection Annotations
=====================
This project is a simple example showing usage of JAX-RS injection annotations.


Building the project:
-------------------------
1. In root directoy

mvn clean package wildfly:deploy

This will build a WAR and run it on running Wildfly

Then open browser and go to:

http://localhost:8080/ex05_2/


Submit form and follow links.
