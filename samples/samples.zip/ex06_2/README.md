MessageBodyReader/Writer
========================
This project is a simple example of writing a MessageBodyReader and MessageBodyWriter

