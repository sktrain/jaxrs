Content Negotiation
===================
This project is an example of using HTTP conneg to pick between XML and JSON.

Damit der vorhandene Test funktioniert ist wieder Übersteuerung des Modulsystems notwendig:
--add-opens java.base/java.lang=ALL-UNNAMED