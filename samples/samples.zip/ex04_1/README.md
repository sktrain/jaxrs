Custom HTTP Method Annotations
========================
This project is a simple example showing usage how to create your own HTTP method annotation.

