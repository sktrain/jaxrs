Exception Mappers
==================
This project is a simple example of using JAX-RS ExceptionHandlers.

