package sk.train;

import sk.train.dao.EmpService;
import sk.train.model.Employee;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Path("/employee")
public class EmployeeController {

	@PostConstruct
	public void init(){
		Employee emp = new Employee(99, "Otto" , "Muster", null, null, LocalDate.now()
				, "murkser", BigDecimal.valueOf(5000),BigDecimal.ZERO,BigDecimal.ONE, BigDecimal.ONE );
		repo.createEmp(emp);
		emp = new Employee(98, "Hugo" , "Meier", null, null, LocalDate.of(2000,1,1)
				, "murkser", BigDecimal.valueOf(6000),BigDecimal.ZERO,BigDecimal.ONE, BigDecimal.ONE );
		repo.createEmp(emp);
	}

	@EJB
	EmpService repo;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Employee empById(@PathParam("id") Long id) {
		return repo.readEmp(id);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> allEmps() {
		return repo.getemps();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	//@Produces(MediaType.APPLICATION_JSON)
	public void createEmp(Employee emp) {
		repo.createEmp(emp);   //was ist, wenn die id schon existiert (update, statt create?)
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Employee updateEmp(@PathParam("id") Long  id, Employee emp) {
		if (repo.readEmp(id) != null) {
			return repo.saveEmp(emp);
		} else {
			return emp;			//war kein Update !!, sollten wir Fehler produzieren?
		}
	}

	@DELETE
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void deleteEmp(@PathParam("id") Long id) {
		repo.removeEmp(id);
	}

}
